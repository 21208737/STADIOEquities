# STADIOEquities — Activation & Dormancy: Data Extract

Nine tables joined on `client_id`, a stable pseudonym. No name, identity number, phone number or email appears anywhere. Registrations run September 2023 to February 2026; **outcomes are known through 2026-08-31 23:59:59** (`observation_end_date`), which is at least six months after the last registration, so the dormancy window is complete for every client. Timestamps are `yyyy-MM-dd HH:mm:ss`. **All monetary values are ZAR.** `session_duration` and `resolution_time` are in **seconds** and **hours** respectively; `feedback_score` is 1-5, higher being better.

## Files

### `1_client_account.csv`
One row per client — registration, KYC, acquisition and stated profile.  
Rows: 2,110

| Column | Description |
|---|---|
| `client_id` | String |
| `registration_date` | Datetime |
| `kyc_completion_date` | Datetime |
| `kyc_status` | Categorical |
| `acquisition_channel` | Categorical |
| `region` | Categorical |
| `age` | Integer |
| `stated_goal` | Categorical |
| `risk_appetite` | Categorical |

### `2_app_web_behaviour.csv`
Event-level app and web behaviour.  
Rows: 27,645

| Column | Description |
|---|---|
| `event_timestamp` | Datetime |
| `client_id` | String |
| `session_id` | String |
| `platform` | Categorical |
| `screen_feature` | Categorical |
| `event_type` | Categorical |
| `onboarding_step` | Categorical |
| `step_outcome` | Categorical |
| `session_duration` | Numeric |
| `login_count` | Integer |

### `3_funding_account_activity.csv`
One row per funding transaction.  
Rows: 4,863

| Column | Description |
|---|---|
| `client_id` | String |
| `transaction_type` | Categorical |
| `amount` | Numeric |
| `funding_status` | Categorical |
| `balance` | Numeric |
| `transaction_timestamp` | Datetime |
| `first_deposit_timestamp` | Datetime |

### `4_trading_activity.csv`
One row per executed trade.  
Rows: 4,798

| Column | Description |
|---|---|
| `trade_timestamp` | Datetime |
| `client_id` | String |
| `instrument` | String |
| `asset_class` | Categorical |
| `trade_side` | Categorical |
| `trade_value` | Numeric |
| `quantity` | Numeric |
| `portfolio_weight` | Numeric |
| `concentration_metric` | Numeric |

### `5_product_subscription.csv`
One row per product or subscription relationship.  
Rows: 960

| Column | Description |
|---|---|
| `client_id` | String |
| `product` | Categorical |
| `subscription_status` | Categorical |
| `start_timestamp` | Datetime |
| `end_timestamp` | Datetime |
| `product_take_up` | Categorical |

### `6_support_feedback.csv`
One row per support ticket.  
Rows: 1,299

| Column | Description |
|---|---|
| `ticket_timestamp` | Datetime |
| `client_id` | String |
| `ticket_reason` | Categorical |
| `ticket_outcome` | Categorical |
| `resolution_time` | Numeric |
| `feedback_score` | Integer |
| `feedback_text` | String |

### `7_marketing_activity.csv`
One row per campaign message sent.  
Rows: 10,372

| Column | Description |
|---|---|
| `client_id` | String |
| `campaign_id` | Categorical |
| `campaign_channel` | Categorical |
| `send_timestamp` | Datetime |
| `open_indicator` | Boolean |
| `click_indicator` | Boolean |
| `acquisition_cost` | Numeric |

### `8_compliance_monitoring.csv`
One row per transaction-monitoring alert.  
Rows: 130

| Column | Description |
|---|---|
| `alert_timestamp` | Datetime |
| `client_id` | String |
| `alert_type` | Categorical |
| `alert_disposition` | Categorical |
| `case_outcome` | Categorical |

### `9_modelling_outcomes.csv`
TARGET table — activation and dormancy outcomes per client.  
Rows: 2,104

| Column | Description |
|---|---|
| `client_id` | String |
| `activation_outcome` | Boolean |
| `first_deposit_timestamp` | Datetime |
| `dormancy_outcome` | Boolean |
| `dormancy_timestamp` | Datetime |
| `observation_end_date` | Datetime |

## Data quality notes

This is an extract from live operational systems and has **not** been cleaned. Expect:

- Missing values in optional / conditionally-populated fields
- Inconsistent casing and stray whitespace in some free-text and categorical fields
- A small number of duplicate records
- Occasional out-of-range or implausible values from data-capture errors
- Some date fields captured in inconsistent formats

## Agreed definitions

**Activation** — a first **successful deposit within 30 calendar days** of registration. `activation_outcome` in table 9 is True on that basis; `first_deposit_timestamp` is supplied separately so you can derive activation on a different window if you prefer.

**Dormancy** — no qualifying activity for **180 consecutive days**, where qualifying activity is a login/session, a successful funding transaction, or a trade. `dormancy_timestamp` is when that condition was first met.

**Balance** — client cash plus the value of holdings, after each transaction. It is a running balance, not an end-of-period snapshot.

**Concentration metric** — the proportion of portfolio value in the client's single largest holding, computed at the point of the trade, range 0-1. `portfolio_weight` is the weight of the instrument on that specific trade row.

**Acquisition cost** — **client-level**, not campaign-level, and repeated on each of that client's marketing rows.

## Two populations, two models

`dormancy_outcome` is **null for clients who never funded** — dormancy is only defined for a funded/active account, so there is nothing to measure. That is not missing data. Split the work:
- **Activation model:** all clients, target `activation_outcome`.
- **Dormancy model:** funded clients only, target `dormancy_outcome`.

## Leakage

The whole of table 9 is outcome data. `first_deposit_timestamp` also appears in table 3 for convenience — it is the label for activation and must not be a feature. For the dormancy model, note that the recency of the last session, transaction and trade is precisely what defines the label; cut behavioural features at a reference point before the dormancy window opens rather than aggregating over the client's whole history.

## Field notes

- `onboarding_step` and `step_outcome` are populated **only on onboarding-related events** and are blank otherwise, as specified.
- `login_count` in table 2 is a **client-level aggregate over the whole observation period**, repeated on each event row — the event-level timestamps are the reliable source for temporal features.
- `open_indicator` and `click_indicator` are blank for SMS, where tracking does not exist.
- `feedback_score` and `feedback_text` exist only where the client responded to the post-resolution survey (~55% of tickets), and free text has been masked for sensitive information.
- Table 8 covers funded clients only — alerts depend on transaction history, so unfunded accounts cannot generate them.

_Synthetic data supplied for the CAP182 capstone project. Not real client data._